var config = {
    // apiKey: "AIzaSyBeREVjj79wuwgHlvTVnslVim0NEBwviy8",
    // authDomain: "tick-tock-apps.firebaseapp.com",
    // databaseURL: "https://tick-tock-apps.firebaseio.com",
    // projectId: "tick-tock-apps",
    // storageBucket: "tick-tock-apps.appspot.com",
    // messagingSenderId: "743557369082"

    apiKey: "AIzaSyASpCyzRmmwVlQUqG7G-ArJ31iogpM5auI",
    authDomain: "test-project-33489.firebaseapp.com",
    databaseURL: "https://test-project-33489.firebaseio.com",
    projectId: "test-project-33489",
    storageBucket: "test-project-33489.appspot.com",
    messagingSenderId: "493620055150"
};