var config = {
    apiKey: "AIzaSyCD4rDC-GWI0-jkmfRmgvdH0PVL_aaa7nE",
    authDomain: "big-bear-entertainment.firebaseapp.com",
    databaseURL: "https://big-bear-entertainment.firebaseio.com",
    projectId: "big-bear-entertainment",
    storageBucket: "big-bear-entertainment.appspot.com",
    messagingSenderId: "391712938904"

    // apiKey: "AIzaSyASpCyzRmmwVlQUqG7G-ArJ31iogpM5auI",
    // authDomain: "test-project-33489.firebaseapp.com",
    // databaseURL: "https://test-project-33489.firebaseio.com",
    // projectId: "test-project-33489",
    // storageBucket: "test-project-33489.appspot.com",
    // messagingSenderId: "493620055150"
};